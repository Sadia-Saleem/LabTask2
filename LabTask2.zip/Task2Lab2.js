//sadia saleem
//question no 1
let Student={
    name:"sadia",
    sem:"6TH",
    sub:"Mobile App Development",
    registrationNo:"fa19-bcs-013"
    
};
function display() {console.log("Name is: "+Student.name+"\nSemester is: "+Student.sem+
"\nSubject is: "+Student.sub+"\nRegistration No is: "+Student.registrationNo);
}
display();
//question no 2
let Student={
    name:"sadia",
    sem:"6TH",
    sub:"Mobile App Development",
    registrationNo:"fa19-bcs-013"
    
};
function display() {console.log("Name is: "+Student.name+"\nSemester is: "+Student.sem+
"\nSubject is: "+Student.sub+"\nRegistration No is: "+Student.registrationNo);
}
display();
delete Student.registrationNo;
console.log("After deletion");
display();
//question no 3
var library=[
    {
        author:"Bill Gates",
        title:"The Road Ahead",
        reading_Status:true
    },

    {
        author: "Steve Jobs",
        title: "Walter Isaacson",
        reading_Status: true
    },

    {
        author: "Suzanne Collins",
        title:  "Mockingjay: The Final Book of The Hunger Games", 
        reading_Status: false
    }
];
function display() {
    for(let i=0;i<library.length;i++){
        console.log("Name of "+i+" Object has Author "+library[i].author+"\nName of "+i+" Object has title "+
        library[i].title+"\nName of "+i+" Object has reading status "+library[i].reading_Status);
    }
}
display();
//question no 4
function sandwichCalculator(bread,cheese) {
    if(bread<2){
        return("we cannot make sandwichs");
    }
    else{
        var sandwichPossible=Math.floor(bread/2);
        console.log("Possible sandwiches ="+sandwichPossible);

    }

    if(cheese<sandwichPossible){
        return("Available cheese="+cheese+" so can make "+cheese+" sandwiches");
    }
    else{
        return("Available bread="+bread+" and cheese="+cheese+" we can make "+sandwichPossible+" sandwiches")
    }    
}

console.log(sandwichCalculator(6,4));
